import React from 'react';


const List = (props) =>{


    return(
        <div className='mt-2'>
            <li>{props.data}</li>
            
        </div>
    )
}

export default List;